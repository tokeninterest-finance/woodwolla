=== WooCommerce Dwolla Gateway ===
Author: skyverge, woocommerce
Tags: woocommerce
Requires at least: 4.1
Tested up to: 4.7.3
Requires WooCommerce at least: 2.5.5
Tested WooCommerce up to: 3.0.0

Adds Dwolla as a payment method for customers on your WooCommerce store. SSL certificate recommended, but not required.

See http://docs.woothemes.com/document/dwolla/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-gateway-dwolla' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
